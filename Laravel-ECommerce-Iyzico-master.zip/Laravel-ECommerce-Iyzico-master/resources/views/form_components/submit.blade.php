<div class="form-group">
    <div class="text-center">
        <button type="submit" dusk="btn-save" class="btn btn-danger">
            <i class="fa fa-btn fa-save"></i> {{ $name }}
        </button>
        <a href="{{$url}}" class="btn btn-primary">Cancel</a>
    </div>
</div>