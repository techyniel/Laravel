<?php

namespace Shetabit\Payment\Exceptions;

class PurchaseFailedException extends \Exception
{
    //
}
