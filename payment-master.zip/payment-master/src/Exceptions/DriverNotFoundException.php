<?php

namespace Shetabit\Payment\Exceptions;

class DriverNotFoundException extends \Exception
{
    //
}
