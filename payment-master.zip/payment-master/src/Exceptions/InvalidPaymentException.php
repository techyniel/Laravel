<?php

namespace Shetabit\Payment\Exceptions;

class InvalidPaymentException extends \Exception
{
    //
}
