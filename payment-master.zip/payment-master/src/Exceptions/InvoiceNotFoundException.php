<?php

namespace Shetabit\Payment\Exceptions;

class InvoiceNotFoundException extends \Exception
{
    //
}
