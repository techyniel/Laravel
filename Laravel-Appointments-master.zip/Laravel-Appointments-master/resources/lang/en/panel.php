<?php

return [
    'site_title' => 'Appointments',
];
